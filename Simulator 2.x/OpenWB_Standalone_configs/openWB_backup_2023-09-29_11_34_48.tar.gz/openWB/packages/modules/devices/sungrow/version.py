from enum import IntEnum


class Version(IntEnum):
    SH = 0
    SG = 1
    SG_winet_dongle = 2
